import {
  Activity,
  AlertCircle,
  ArrowRight,
  BarChart3,
  Bot,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Code2,
  FileVideo,
  Globe2,
  KeyRound,
  Layers3,
  LockKeyhole,
  Megaphone,
  MessageSquareText,
  PlayCircle,
  RadioTower,
  RefreshCcw,
  Send,
  Settings2,
  ShieldCheck,
  Sparkles,
  UploadCloud,
  Wand2,
  type LucideIcon
} from "lucide-react";

const platforms = [
  "X/Twitter",
  "Instagram",
  "Facebook",
  "LinkedIn",
  "TikTok",
  "YouTube Shorts",
  "Threads",
  "Bluesky",
  "Pinterest",
  "Google Business"
];

const pricing = [
  {
    name: "Launch",
    price: "$29",
    description: "For solo creators getting every channel moving.",
    features: ["5 connected accounts", "Unlimited drafts", "Scheduled publishing", "AI agent commands"]
  },
  {
    name: "Studio",
    price: "$49",
    description: "For builders posting daily across many channels.",
    features: ["20 connected accounts", "Bulk video scheduling", "Analytics snapshots", "API key add-on"],
    featured: true
  },
  {
    name: "Scale",
    price: "$99",
    description: "For small teams and operators managing brands.",
    features: ["Unlimited accounts", "Team workspaces", "Priority queueing", "Growth reporting"]
  }
];

const faqs = [
  ["Can this publish to real social accounts?", "Yes. The backend is designed for official OAuth flows and provider APIs. Each platform still requires credentials, scopes, and production approval."],
  ["Do users share passwords?", "No. Users connect accounts through each provider's official authorization screen, and the API stores encrypted OAuth tokens only."],
  ["Can an AI agent create posts?", "The first API surface is shaped so an agent can create drafts, schedule posts, request status, and later connect through REST or MCP-style endpoints."],
  ["What happens when one platform fails?", "Every target gets its own publish attempt, status, retry policy, and error message so the rest of the post can still ship."]
];

const workflowSteps: Array<{ icon: LucideIcon; title: string; body: string }> = [
  { icon: MessageSquareText, title: "Ask your agent", body: "Create a draft, attach media, or schedule a batch through the API." },
  { icon: ShieldCheck, title: "Validate limits", body: "The composer catches caption, media, and permission issues before queueing." },
  { icon: CalendarDays, title: "Queue posts", body: "Immediate and scheduled publishing share the same durable job pipeline." },
  { icon: Activity, title: "Track results", body: "Normalize views, likes, comments, and URLs into one reporting surface." }
];

const connectedAccounts = [
  { platform: "Instagram", handle: "@launchstudio", status: "Ready" },
  { platform: "TikTok", handle: "@launchstudio", status: "Ready" },
  { platform: "LinkedIn", handle: "Launch Studio", status: "Ready" },
  { platform: "YouTube", handle: "Launch Studio", status: "Reconnect" }
];

const validations = [
  "Caption fits all selected platforms",
  "Video duration works for Reels, TikTok, and Shorts",
  "LinkedIn will publish without platform-only hashtags",
  "YouTube needs a title before publishing"
];

const scheduledPosts = [
  { day: "Mon", time: "9:00", status: "Queued", title: "Product clip 01" },
  { day: "Tue", time: "9:00", status: "Queued", title: "Feature walkthrough" },
  { day: "Wed", time: "9:00", status: "Review", title: "Founder note" },
  { day: "Thu", time: "9:00", status: "Queued", title: "Customer proof" }
];

function App() {
  return (
    <main>
      <nav className="nav">
        <a className="brand" href="#top" aria-label="Social Bridge Studio home">
          <span className="brand-mark"><RadioTower size={20} /></span>
          Social Bridge Studio
        </a>
        <div className="nav-links">
          <a href="#workflow">Workflow</a>
          <a href="#platforms">Platforms</a>
          <a href="#pricing">Pricing</a>
          <a href="#faq">FAQ</a>
        </div>
        <a className="nav-cta" href="#demo">Start free <ArrowRight size={16} /></a>
      </nav>

      <section id="top" className="hero section-shell">
        <div className="hero-copy reveal">
          <div className="eyebrow"><Sparkles size={16} /> AI-ready publishing studio</div>
          <h1>Post once. Ship everywhere your audience lives.</h1>
          <p>
            Connect your channels, hand your agent the finished content, and schedule a full week of posts without bouncing between ten apps.
          </p>
          <div className="hero-actions">
            <a className="primary-button" href="#demo">Build your first post <Send size={18} /></a>
            <a className="secondary-button" href="#backend">Backend plan <Code2 size={18} /></a>
          </div>
          <div className="metric-strip" aria-label="Product metrics">
            <span><strong>10</strong> platforms</span>
            <span><strong>2 min</strong> setup goal</span>
            <span><strong>1</strong> posting queue</span>
          </div>
        </div>

        <div id="demo" className="composer-card reveal delay-1" aria-label="Post composer preview">
          <div className="composer-header">
            <span><Bot size={18} /> Agent draft</span>
            <button type="button" aria-label="Preview post"><PlayCircle size={18} /></button>
          </div>
          <div className="prompt-bubble">Schedule these product clips Monday to Friday at 9 AM. Use the same caption, but tailor hashtags per network.</div>
          <div className="upload-panel">
            <UploadCloud size={24} />
            <div>
              <strong>5 videos ready</strong>
              <span>Aspect ratios and duration checked per platform</span>
            </div>
          </div>
          <div className="platform-cloud">
            {platforms.slice(0, 8).map((platform) => <span key={platform}>{platform}</span>)}
          </div>
          <div className="schedule-row">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((day) => (
              <div key={day}><strong>{day}</strong><span>9:00</span></div>
            ))}
          </div>
          <div className="success-line"><Check size={18} /> Queued across every selected account.</div>
        </div>
      </section>

      <section id="product" className="section-shell product-section">
        <div className="section-heading compact-heading">
          <div className="eyebrow"><Settings2 size={16} /> Product workflow</div>
          <h2>The actual app flow, not just the marketing page.</h2>
          <p>Users need one place to connect accounts, compose a post, validate every destination, schedule content, and see what shipped.</p>
        </div>

        <div className="app-shell-preview">
          <aside className="app-sidebar" aria-label="Product navigation preview">
            <strong>Studio</strong>
            {[
              [Globe2, "Accounts"],
              [FileVideo, "Composer"],
              [CalendarDays, "Calendar"],
              [BarChart3, "Analytics"],
              [KeyRound, "API keys"]
            ].map(([Icon, label]) => (
              <span key={label as string}><Icon size={17} /> {label as string}</span>
            ))}
          </aside>

          <div className="app-board">
            <div className="board-header">
              <div>
                <span>Campaign draft</span>
                <h3>Launch week clips</h3>
              </div>
              <button type="button"><Send size={17} /> Schedule batch</button>
            </div>

            <div className="workflow-board-grid">
              <article className="workflow-panel accounts-panel">
                <h4><Globe2 size={18} /> Connected accounts</h4>
                {connectedAccounts.map((account) => (
                  <div className="account-row" key={`${account.platform}-${account.handle}`}>
                    <span>{account.platform}</span>
                    <small>{account.handle}</small>
                    <strong className={account.status === "Ready" ? "good" : "warn"}>{account.status}</strong>
                  </div>
                ))}
              </article>

              <article className="workflow-panel composer-panel">
                <h4><FileVideo size={18} /> Composer</h4>
                <div className="textarea-preview">New release is live. Here are the three changes creators asked for most...</div>
                <div className="media-preview"><UploadCloud size={20} /> launch-week-demo.mp4</div>
                <div className="target-pills">
                  {platforms.slice(0, 6).map((platform) => <span key={platform}>{platform}</span>)}
                </div>
              </article>

              <article className="workflow-panel validation-panel">
                <h4><ShieldCheck size={18} /> Platform checks</h4>
                {validations.map((validation, index) => (
                  <div className="validation-row" key={validation}>
                    {index === validations.length - 1 ? <AlertCircle size={17} /> : <CheckCircle2 size={17} />}
                    <span>{validation}</span>
                  </div>
                ))}
              </article>

              <article className="workflow-panel schedule-panel">
                <h4><CalendarDays size={18} /> Schedule</h4>
                {scheduledPosts.map((post) => (
                  <div className="mini-event" key={post.title}>
                    <strong>{post.day}</strong>
                    <span>{post.time}</span>
                    <p>{post.title}</p>
                    <small>{post.status}</small>
                  </div>
                ))}
              </article>

              <article className="workflow-panel status-panel">
                <h4><RefreshCcw size={18} /> Publish status</h4>
                <div className="status-meters">
                  <span style={{ width: "86%" }}>Published</span>
                  <span style={{ width: "62%" }}>Queued</span>
                  <span style={{ width: "28%" }}>Needs action</span>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>

      <section className="logo-band" aria-label="Featured benefits">
        {['Official OAuth', 'Encrypted tokens', 'Scheduled jobs', 'Provider retries', 'Analytics sync'].map((item) => <span key={item}>{item}</span>)}
      </section>

      <section id="workflow" className="section-shell split-section">
        <div>
          <div className="eyebrow"><Wand2 size={16} /> Workflow</div>
          <h2>From agent prompt to scheduled campaign.</h2>
          <p>Creators should see exactly what will happen before anything publishes: connected accounts, platform checks, scheduled time, and retry status.</p>
        </div>
        <div className="steps-grid">
          {workflowSteps.map(({ icon: Icon, title, body }) => (
            <article className="step-card" key={title}>
              <Icon size={22} />
              <h3>{title}</h3>
              <p>{body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section-shell analytics-section">
        <div className="analytics-card">
          <div className="bar-chart" aria-hidden="true">
            {[42, 58, 71, 48, 86, 64, 92].map((height, index) => <span key={index} style={{ height: `${height}%` }} />)}
          </div>
          <div>
            <div className="eyebrow"><Activity size={16} /> Analytics</div>
            <h2>Know what worked before you post again.</h2>
            <p>Every platform speaks a slightly different metrics language. The backend normalizes snapshots so the UI can show wins without hiding provider limits.</p>
          </div>
        </div>
      </section>

      <section id="platforms" className="section-shell">
        <div className="section-heading">
          <div className="eyebrow"><Layers3 size={16} /> Supported channels</div>
          <h2>One composer, platform-specific rules.</h2>
        </div>
        <div className="platform-grid">
          {platforms.map((platform) => <div className="platform-card" key={platform}><Megaphone size={18} /> {platform}</div>)}
        </div>
      </section>

      <section id="backend" className="section-shell code-section">
        <div>
          <div className="eyebrow"><LockKeyhole size={16} /> Backend foundation</div>
          <h2>Built around real OAuth, not password sharing.</h2>
          <p>Each provider gets a connector that owns scopes, token refresh, media upload, publishing, analytics, and webhook verification.</p>
        </div>
        <pre>{`interface SocialConnector {\n  getAuthorizationUrl(workspaceId: string): string\n  exchangeCode(code: string): Promise<TokenSet>\n  publish(target: PublishTarget): Promise<PublishResult>\n  refreshAnalytics(postId: string): Promise<AnalyticsSnapshot>\n}`}</pre>
      </section>

      <section id="pricing" className="section-shell">
        <div className="section-heading">
          <div className="eyebrow"><Clock3 size={16} /> Pricing</div>
          <h2>Simple plans for creators and small teams.</h2>
        </div>
        <div className="pricing-grid">
          {pricing.map((plan) => (
            <article className={`pricing-card ${plan.featured ? 'featured' : ''}`} key={plan.name}>
              <span>{plan.name}</span>
              <h3>{plan.price}<small>/mo</small></h3>
              <p>{plan.description}</p>
              <ul>
                {plan.features.map((feature) => <li key={feature}><Check size={16} /> {feature}</li>)}
              </ul>
              <a href="#demo">Start trial <ArrowRight size={16} /></a>
            </article>
          ))}
        </div>
      </section>

      <section id="faq" className="section-shell faq-section">
        <div className="section-heading">
          <div className="eyebrow"><ChevronDown size={16} /> FAQ</div>
          <h2>Questions before the real integrations begin.</h2>
        </div>
        <div className="faq-list">
          {faqs.map(([question, answer]) => (
            <details key={question}>
              <summary>{question}</summary>
              <p>{answer}</p>
            </details>
          ))}
        </div>
      </section>

      <footer>
        <span>Social Bridge Studio</span>
        <p>Multi-platform publishing, scheduling, and analytics for creators who want one calm control room.</p>
      </footer>
    </main>
  );
}

export default App;