# Social Bridge Studio

A React/Vite frontend and separate TypeScript API for a multi-platform social posting product inspired by the structure of Post Bridge, with original branding, copy, and implementation.

## Apps

- `frontend/` - Vite + React + TypeScript marketing and product UI.
- `api/` - Node.js + TypeScript API skeleton for auth, OAuth connections, posts, scheduling, analytics, and billing.
- `packages/shared/` - Shared TypeScript domain types.

## Local Setup

```bash
npm install
npm run dev
npm run dev:api
```

The backend is scaffolded around real OAuth and real posting, but provider credentials, app approvals, token encryption keys, database, queue, and object storage must be configured before production publishing can work.

## Backend Build-Out Order

1. Add database migrations and persistence for users, workspaces, social accounts, media assets, posts, post targets, publish attempts, and analytics snapshots.
2. Add auth and workspace membership.
3. Implement one OAuth provider end to end, including state validation, token refresh, encrypted token storage, post validation, media upload, and publish retries.
4. Expand providers one at a time using the connector interface.
5. Add durable queues for scheduled publishing, retries, analytics refresh, and webhook handling.
6. Add Stripe billing, plan limits, API keys, and an MCP-compatible endpoint after core publishing works.