export type SocialPlatform =
  | "x"
  | "instagram"
  | "facebook"
  | "linkedin"
  | "tiktok"
  | "youtube"
  | "threads"
  | "bluesky"
  | "pinterest"
  | "google-business";

export type PostStatus = "draft" | "scheduled" | "publishing" | "published" | "failed";

export type MediaKind = "image" | "video" | "carousel";

export interface Workspace {
  id: string;
  name: string;
  plan: "starter" | "creator" | "growth" | "pro";
  createdAt: string;
}

export interface SocialAccount {
  id: string;
  workspaceId: string;
  platform: SocialPlatform;
  displayName: string;
  handle: string;
  avatarUrl?: string;
  connectedAt: string;
  tokenStatus: "valid" | "refresh-needed" | "revoked";
}

export interface MediaAsset {
  id: string;
  workspaceId: string;
  kind: MediaKind;
  storageKey: string;
  mimeType: string;
  sizeBytes: number;
  durationSeconds?: number;
  width?: number;
  height?: number;
}

export interface PostTarget {
  id: string;
  socialAccountId: string;
  platform: SocialPlatform;
  status: PostStatus;
  providerPostId?: string;
  providerUrl?: string;
  lastError?: string;
}

export interface Post {
  id: string;
  workspaceId: string;
  caption: string;
  mediaAssetIds: string[];
  targets: PostTarget[];
  scheduledFor?: string;
  status: PostStatus;
  createdAt: string;
  updatedAt: string;
}

export interface AnalyticsSnapshot {
  postTargetId: string;
  capturedAt: string;
  views?: number;
  likes?: number;
  comments?: number;
  shares?: number;
  saves?: number;
  clicks?: number;
}