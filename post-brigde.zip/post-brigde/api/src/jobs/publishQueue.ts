import type { Post } from "@social-bridge/shared";

export interface PublishJob {
  id: string;
  post: Post;
  runAt: string;
  attempts: number;
}

export async function enqueuePublishJob(job: PublishJob): Promise<void> {
  void job;
  throw new Error("Publish queue is not configured yet. Add Redis/BullMQ or another durable queue before enabling scheduled posting.");
}