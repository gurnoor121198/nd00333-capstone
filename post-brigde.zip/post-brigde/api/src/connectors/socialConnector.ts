import type { AnalyticsSnapshot, Post, SocialAccount, SocialPlatform } from "@social-bridge/shared";

export interface OAuthState {
  workspaceId: string;
  redirectUri: string;
  nonce: string;
}

export interface TokenSet {
  accessToken: string;
  refreshToken?: string;
  expiresAt?: string;
  scopes: string[];
}

export interface PublishResult {
  providerPostId: string;
  providerUrl?: string;
  publishedAt: string;
}

export interface SocialConnector {
  platform: SocialPlatform;
  getAuthorizationUrl(state: OAuthState): string;
  exchangeCode(code: string, state: OAuthState): Promise<TokenSet>;
  refreshToken(account: SocialAccount): Promise<TokenSet>;
  validatePost(post: Post, account: SocialAccount): Promise<string[]>;
  publish(post: Post, account: SocialAccount): Promise<PublishResult>;
  refreshAnalytics(account: SocialAccount, providerPostId: string): Promise<AnalyticsSnapshot>;
}