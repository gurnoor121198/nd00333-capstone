import type { SocialPlatform } from "@social-bridge/shared";
import type { SocialConnector } from "./socialConnector.js";

const pendingProviders: SocialPlatform[] = [
  "x",
  "instagram",
  "facebook",
  "linkedin",
  "tiktok",
  "youtube",
  "threads",
  "bluesky",
  "pinterest",
  "google-business"
];

export function getConnector(platform: SocialPlatform): SocialConnector {
  throw new Error(`Connector for ${platform} is not implemented yet. Pending providers: ${pendingProviders.join(", ")}`);
}

export function listPendingProviders(): SocialPlatform[] {
  return pendingProviders;
}