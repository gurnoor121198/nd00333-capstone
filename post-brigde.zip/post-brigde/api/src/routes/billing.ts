import { Router } from "express";

export const billingRouter = Router();

billingRouter.get("/billing/plans", (_request, response) => {
  response.json({
    plans: [
      { id: "starter", connectedAccounts: 5, apiAddOn: false },
      { id: "creator", connectedAccounts: 15, apiAddOn: true },
      { id: "growth", connectedAccounts: 50, apiAddOn: true },
      { id: "pro", connectedAccounts: "unlimited", apiAddOn: true }
    ]
  });
});