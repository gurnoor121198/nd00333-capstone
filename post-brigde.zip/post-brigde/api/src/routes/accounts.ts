import { Router } from "express";
import { listPendingProviders } from "../connectors/registry.js";

export const accountsRouter = Router();

accountsRouter.get("/accounts/providers", (_request, response) => {
  response.json({ providers: listPendingProviders() });
});

accountsRouter.get("/accounts", (_request, response) => {
  response.json({
    accounts: [],
    message: "Connected account persistence is not implemented yet. Add auth, database tables, encrypted token storage, and OAuth callbacks next."
  });
});