import { Router } from "express";

export const schedulesRouter = Router();

schedulesRouter.get("/schedules", (_request, response) => {
  response.json({
    scheduledPosts: [],
    message: "Scheduled posts will be backed by database records and a durable publish queue."
  });
});