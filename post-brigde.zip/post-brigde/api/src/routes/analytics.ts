import { Router } from "express";

export const analyticsRouter = Router();

analyticsRouter.get("/analytics/summary", (_request, response) => {
  response.json({
    views: 0,
    likes: 0,
    comments: 0,
    shares: 0,
    message: "Analytics normalization will read provider snapshots after publishing connectors are implemented."
  });
});