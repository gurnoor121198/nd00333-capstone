import { Router } from "express";
import { listPendingProviders } from "../connectors/registry.js";

export const healthRouter = Router();

healthRouter.get("/health", (_request, response) => {
  response.json({
    ok: true,
    service: "social-bridge-api",
    pendingProviders: listPendingProviders()
  });
});