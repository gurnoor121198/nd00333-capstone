import { Router } from "express";
import { z } from "zod";

const createPostSchema = z.object({
  workspaceId: z.string().min(1),
  caption: z.string().min(1).max(2200),
  mediaAssetIds: z.array(z.string()).default([]),
  socialAccountIds: z.array(z.string()).min(1),
  scheduledFor: z.string().datetime().optional()
});

const updatePostSchema = createPostSchema.partial().extend({
  caption: z.string().min(1).max(2200).optional()
});

const scheduleSchema = z.object({
  scheduledFor: z.string().datetime()
});

export const postsRouter = Router();

postsRouter.get("/posts", (_request, response) => {
  response.json({
    posts: [],
    message: "Post listing will read drafts, scheduled posts, target status, and provider URLs from the database."
  });
});

postsRouter.post("/posts", (request, response) => {
  const parsed = createPostSchema.safeParse(request.body);

  if (!parsed.success) {
    response.status(400).json({ error: "Invalid post payload", issues: parsed.error.flatten() });
    return;
  }

  response.status(202).json({
    status: "accepted",
    message: "Post validation accepted. Persistence, queueing, and provider publish jobs are the next implementation step.",
    draft: parsed.data
  });
});

postsRouter.get("/posts/:postId", (request, response) => {
  response.json({
    id: request.params.postId,
    status: "pending-persistence",
    targets: [],
    message: "Post detail will include per-platform validation, publish attempts, and analytics snapshots."
  });
});

postsRouter.patch("/posts/:postId", (request, response) => {
  const parsed = updatePostSchema.safeParse(request.body);

  if (!parsed.success) {
    response.status(400).json({ error: "Invalid post update", issues: parsed.error.flatten() });
    return;
  }

  response.json({ id: request.params.postId, status: "updated", draft: parsed.data });
});

postsRouter.post("/posts/:postId/schedule", (request, response) => {
  const parsed = scheduleSchema.safeParse(request.body);

  if (!parsed.success) {
    response.status(400).json({ error: "Invalid schedule payload", issues: parsed.error.flatten() });
    return;
  }

  response.status(202).json({
    id: request.params.postId,
    status: "scheduled",
    scheduledFor: parsed.data.scheduledFor,
    message: "Durable queue integration is required before scheduled jobs publish automatically."
  });
});

postsRouter.post("/posts/:postId/publish", (request, response) => {
  response.status(202).json({
    id: request.params.postId,
    status: "queued-for-publish",
    message: "Publishing will fan out one job per selected social account after persistence and connectors are implemented."
  });
});

postsRouter.post("/post-targets/:targetId/retry", (request, response) => {
  response.status(202).json({
    id: request.params.targetId,
    status: "retry-queued",
    message: "Retries will use the publish attempt history and connector error classification."
  });
});