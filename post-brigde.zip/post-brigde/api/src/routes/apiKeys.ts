import { Router } from "express";
import { z } from "zod";

const apiKeySchema = z.object({
  workspaceId: z.string().min(1),
  name: z.string().min(1).max(80),
  scopes: z.array(z.enum(["accounts:read", "posts:write", "posts:read", "analytics:read"])).min(1)
});

export const apiKeysRouter = Router();

apiKeysRouter.post("/api-keys", (request, response) => {
  const parsed = apiKeySchema.safeParse(request.body);

  if (!parsed.success) {
    response.status(400).json({ error: "Invalid API key payload", issues: parsed.error.flatten() });
    return;
  }

  response.status(201).json({
    id: crypto.randomUUID(),
    name: parsed.data.name,
    scopes: parsed.data.scopes,
    tokenPreview: "sb_live_...",
    message: "Store only hashed API keys and show the raw token once when persistence is implemented."
  });
});

apiKeysRouter.delete("/api-keys/:apiKeyId", (request, response) => {
  response.json({ id: request.params.apiKeyId, status: "revoked" });
});