import { Router } from "express";
import { z } from "zod";
import { getConnector } from "../connectors/registry.js";

const platformSchema = z.enum([
  "x",
  "instagram",
  "facebook",
  "linkedin",
  "tiktok",
  "youtube",
  "threads",
  "bluesky",
  "pinterest",
  "google-business"
]);

export const oauthRouter = Router();

oauthRouter.get("/oauth/:platform/start", (request, response) => {
  const parsed = platformSchema.safeParse(request.params.platform);

  if (!parsed.success) {
    response.status(404).json({ error: "Unsupported platform" });
    return;
  }

  try {
    const connector = getConnector(parsed.data);
    const authorizationUrl = connector.getAuthorizationUrl({
      workspaceId: String(request.query.workspaceId ?? ""),
      redirectUri: String(request.query.redirectUri ?? ""),
      nonce: crypto.randomUUID()
    });

    response.json({ authorizationUrl });
  } catch (error) {
    response.status(501).json({ error: error instanceof Error ? error.message : "Connector unavailable" });
  }
});