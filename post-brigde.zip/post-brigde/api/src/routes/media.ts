import { Router } from "express";
import { z } from "zod";

const uploadUrlSchema = z.object({
  workspaceId: z.string().min(1),
  fileName: z.string().min(1),
  mimeType: z.string().min(1),
  sizeBytes: z.number().int().positive()
});

export const mediaRouter = Router();

mediaRouter.post("/media/upload-url", (request, response) => {
  const parsed = uploadUrlSchema.safeParse(request.body);

  if (!parsed.success) {
    response.status(400).json({ error: "Invalid media payload", issues: parsed.error.flatten() });
    return;
  }

  const mediaAssetId = crypto.randomUUID();

  response.status(201).json({
    mediaAssetId,
    uploadUrl: `https://object-storage.example/${parsed.data.workspaceId}/${mediaAssetId}/${encodeURIComponent(parsed.data.fileName)}`,
    headers: { "content-type": parsed.data.mimeType },
    message: "Replace this placeholder with a signed object-storage URL before enabling real uploads."
  });
});