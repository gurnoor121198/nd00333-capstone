import "dotenv/config";
import cors from "cors";
import express from "express";
import helmet from "helmet";
import pino from "pino";
import { accountsRouter } from "./routes/accounts.js";
import { analyticsRouter } from "./routes/analytics.js";
import { apiKeysRouter } from "./routes/apiKeys.js";
import { billingRouter } from "./routes/billing.js";
import { healthRouter } from "./routes/health.js";
import { mediaRouter } from "./routes/media.js";
import { oauthRouter } from "./routes/oauth.js";
import { postsRouter } from "./routes/posts.js";
import { schedulesRouter } from "./routes/schedules.js";

const logger = pino({ name: "social-bridge-api" });
const app = express();
const port = Number(process.env.PORT ?? 4000);

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_ORIGIN ?? "http://localhost:5173" }));
app.use(express.json({ limit: "2mb" }));

app.use("/api", healthRouter);
app.use("/api", accountsRouter);
app.use("/api", analyticsRouter);
app.use("/api", apiKeysRouter);
app.use("/api", billingRouter);
app.use("/api", oauthRouter);
app.use("/api", mediaRouter);
app.use("/api", postsRouter);
app.use("/api", schedulesRouter);

app.use((error: unknown, _request: express.Request, response: express.Response, _next: express.NextFunction) => {
  logger.error({ error }, "Unhandled API error");
  response.status(500).json({ error: "Internal server error" });
});

app.listen(port, () => {
  logger.info({ port }, "API server listening");
});