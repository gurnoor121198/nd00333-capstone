# Implementation Plan

This is the build plan for turning the Post Bridge-inspired concept into this project's own multi-platform posting product.

## Phase 1: Product Frontend

- Expand the landing page into a complete product preview.
- Add dashboard sections for account connection, post composer, platform validation, scheduling, and analytics.
- Keep all branding, copy, visuals, and UI original.
- Show real user flows even before backend persistence is complete.

## Phase 2: API Foundation

- Keep the API separate from the Vite frontend.
- Add auth, workspace membership, and plan limits.
- Add database tables for users, workspaces, social accounts, media, posts, post targets, publish attempts, and analytics snapshots.
- Add encrypted token storage before real OAuth callbacks save provider tokens.

## Phase 3: Posting Pipeline

- Create post drafts with caption, media, selected accounts, and optional schedule time.
- Validate every selected target using platform-specific rules.
- Enqueue one publish job per target account.
- Retry transient failures without blocking successful platforms.
- Store provider post URLs and errors per target.

## Phase 4: Real Providers

- Implement one provider end to end first.
- Recommended first provider: Bluesky or X/Twitter.
- Add Meta, LinkedIn, TikTok, YouTube, Pinterest, Threads, and Google Business after the connector pattern is proven.
- Keep provider approval, scopes, media limits, and analytics support documented per platform.

## Phase 5: Agent/API Layer

- Add scoped API keys.
- Add REST endpoints for agent workflows: list accounts, upload media, create post, validate post, schedule, publish, status, and analytics.
- Add MCP-compatible tools after REST service methods are stable.

## Current Implementation Slice

- Root npm workspace is created.
- Vite React frontend is scaffolded manually because npm scaffolding hit registry/auth problems.
- Express TypeScript API skeleton exists.
- Shared TypeScript domain types exist.
- Product dashboard preview is now part of the landing page.
- Backend implementation details are documented in `docs/backend-roadmap.md` and `docs/multi-platform-posting-plan.md`.

## Next Engineering Tasks

1. Fix local npm install/registry access and run `npm run typecheck` plus `npm run build`.
2. Add database tooling and migrations.
3. Add auth/session middleware.
4. Add media upload metadata routes.
5. Implement one real OAuth connector.
6. Add a durable publish queue.