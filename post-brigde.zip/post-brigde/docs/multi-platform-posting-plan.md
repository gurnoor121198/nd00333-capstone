# Multi-Platform Posting Plan

This plan is based on the visible Post Bridge website walkthrough and product sections. Use it as functional inspiration only: keep our brand, copy, UI assets, and implementation original.

## Website Functions Observed

1. AI agent connection
   - Users connect an AI agent such as Claude, ChatGPT, Cursor, Hermes, Grokbot, or any MCP-compatible client.
   - Fast setup is positioned as one-click for supported agent directories, with manual MCP configuration for other clients.
   - REST API and CLI access are offered for custom workflows.

2. Social account connection
   - Users connect social accounts through official provider authentication.
   - Multiple accounts can exist on the same platform.
   - Account limits depend on the user's plan.
   - The user should not share raw social passwords.

3. Multi-platform post creation
   - A user or AI agent can create one post and send it to several social accounts.
   - The demonstrated flow includes uploading media, creating a post, selecting multiple accounts, and publishing everywhere.
   - Supported content includes text, images, video, reels/shorts, and carousel posts.

4. Scheduling
   - Users can schedule one post or a full week of posts from a single instruction.
   - The demo shows batch scheduling across weekdays at the same time.
   - Scheduled posts land in a calendar where users can edit, reschedule, delete, or approve before publishing.

5. Analytics
   - Users can ask for views, likes, comments, and performance over a time period.
   - The system highlights winning posts and can queue more content in a similar style.
   - Analytics support is platform-dependent and should be clearly marked where limited.

6. Supported platforms
   - Initial platform set: X/Twitter, Instagram, LinkedIn, Facebook, TikTok, YouTube, Bluesky, Threads, Pinterest, and Google Business.
   - The frontend should show platform support clearly and indicate future platforms.

7. Pricing and limits
   - Plans are based mainly on connected social account limits and advanced features.
   - Features include unlimited posts for paid users, scheduling, MCP agent connection, carousel posts, bulk video scheduling, content studio access, API add-on, analytics, team members, consulting, and priority support.

8. Trust and onboarding
   - Strong messaging around saving time, replacing expensive social schedulers, and keeping the product simple.
   - Testimonials and outcome screenshots are used as proof.
   - FAQ addresses reach, passwords, supported platforms, account limits, cancellation, refunds, and agent integration.

## Product Scope for Our App

Build a social publishing platform where users can:

- Sign up and create a workspace.
- Connect multiple social accounts using OAuth or platform-specific auth.
- Upload images, videos, and carousel media.
- Compose one post and select many target accounts.
- Validate captions and media against every selected platform's rules.
- Publish immediately or schedule for later.
- View a calendar/list of drafts, scheduled posts, publishing jobs, failures, and published posts.
- Retry failed platform targets independently.
- View normalized analytics across supported platforms.
- Use API keys and, later, an MCP-compatible agent endpoint.
- Manage billing, plan limits, connected accounts, and team access.

## Posting Workflow

1. User connects accounts
   - User selects a platform.
   - Backend creates an OAuth authorization URL with a signed state value.
   - Provider redirects back to the API callback.
   - API validates state, exchanges the code for tokens, encrypts tokens, stores provider metadata, and marks the account connected.

2. User creates content
   - User writes a caption or asks an AI agent/API client to create one.
   - User uploads media.
   - Media is stored in object storage and metadata is saved in the database.
   - Optional worker extracts thumbnails and validates dimensions, duration, file size, and MIME type.

3. User selects destinations
   - User chooses one or more social accounts.
   - Frontend requests platform validation from the API.
   - API runs connector-specific validators for caption length, hashtag rules, media count, aspect ratio, video duration, account permissions, and OAuth scopes.

4. User publishes or schedules
   - Immediate publish creates a `Post` record and `PostTarget` records, then enqueues publish jobs now.
   - Scheduled publish creates the same records but sets `runAt` in the future.
   - Every selected account gets its own publish target and status.

5. Worker publishes
   - Worker loads the post, media, social account, and connector.
   - Connector refreshes tokens if needed.
   - Connector uploads media if required by that provider.
   - Connector creates the platform post.
   - API records provider post ID, provider URL, published timestamp, or detailed failure.

6. Worker handles failures
   - Retry transient errors with backoff.
   - Do not retry permanent validation or permission errors.
   - Keep failures isolated per target so one failed platform does not block the others.

7. Analytics refresh
   - Scheduled analytics jobs fetch metrics from supported providers.
   - Normalize metrics into a common snapshot model.
   - Show unsupported metrics as unavailable, not zero.

## Backend Architecture

Recommended stack for this project:

- API: Node.js, TypeScript, Express or Fastify.
- Database: PostgreSQL.
- ORM/migrations: Prisma or Drizzle.
- Queue: Redis + BullMQ.
- Object storage: S3-compatible storage.
- Auth: Better Auth, Auth.js, Clerk, or custom session auth.
- Billing: Stripe.
- Logging/monitoring: Pino plus an error tracking service.

Core modules:

- `auth`: signup, login, sessions, password reset, workspace membership.
- `accounts`: connected social accounts and OAuth callbacks.
- `connectors`: provider-specific OAuth, validation, publishing, upload, analytics.
- `media`: upload URLs, media metadata, validation, thumbnails, optional transcoding.
- `posts`: drafts, target selection, status, publish attempts.
- `schedules`: calendar, queued jobs, rescheduling, cancellation.
- `analytics`: normalized metrics and periodic refresh.
- `billing`: plans, account limits, API add-ons, team limits.
- `agent-api`: API keys, REST endpoints, later MCP tools.

## Data Model

Minimum tables:

- `users`: account identity and auth references.
- `workspaces`: teams/brands and plan ownership.
- `workspace_members`: user roles per workspace.
- `social_accounts`: provider, handle, encrypted tokens, scopes, status, token expiry.
- `media_assets`: storage key, type, dimensions, duration, size, status.
- `posts`: caption, workspace, status, scheduled time, created by.
- `post_media`: post-to-media join table with ordering.
- `post_targets`: one row per selected social account.
- `publish_attempts`: attempt history, provider errors, retry count.
- `analytics_snapshots`: metrics per post target over time.
- `api_keys`: agent/API access tokens with scopes.
- `billing_customers`: Stripe customer/subscription state.
- `audit_events`: security and publishing audit trail.

## Connector Interface

Every platform should implement the same shape:

```ts
interface SocialConnector {
  platform: SocialPlatform;
  getAuthorizationUrl(state: OAuthState): string;
  exchangeCode(code: string, state: OAuthState): Promise<TokenSet>;
  refreshToken(account: SocialAccount): Promise<TokenSet>;
  validatePost(post: Post, account: SocialAccount): Promise<ValidationIssue[]>;
  uploadMedia(media: MediaAsset[], account: SocialAccount): Promise<ProviderMedia[]>;
  publish(post: Post, account: SocialAccount): Promise<PublishResult>;
  refreshAnalytics(account: SocialAccount, providerPostId: string): Promise<AnalyticsSnapshot>;
}
```

## Platform Rollout Order

1. Bluesky or X/Twitter first, because they are usually simpler than the highest-friction video platforms.
2. LinkedIn text/image posting.
3. Facebook Pages and Instagram publishing through Meta review.
4. YouTube Shorts upload flow.
5. TikTok upload/publish flow.
6. Pinterest pins.
7. Threads.
8. Google Business posts.

Ship one provider completely before adding the next provider. A half-working ten-platform backend is harder to debug than one reliable connector pattern.

## Frontend Screens

1. Marketing page
   - Hero: post once to every channel.
   - Agent demo: AI prompt creates a multi-platform post.
   - Scheduling section: week of content queued from one command.
   - Analytics section: performance summary and suggested next posts.
   - Supported platforms grid.
   - API/MCP integration section.
   - Pricing cards.
   - FAQ.

2. Dashboard
   - Upcoming scheduled posts.
   - Recent publish status.
   - Connected account health.
   - Analytics highlights.

3. Account connections
   - Platform list.
   - OAuth connect buttons.
   - Connected accounts table.
   - Token status and reconnect action.

4. Composer
   - Caption editor.
   - Media upload.
   - Platform/account selector.
   - Per-platform validation warnings.
   - Preview by destination.
   - Publish now or schedule.

5. Calendar
   - Drafts, scheduled posts, failed posts, and published posts.
   - Drag/reschedule support later.
   - Edit/delete/retry actions.

6. Analytics
   - Views, likes, comments, shares, saves, and clicks where available.
   - Platform filters.
   - Post-level drilldown.

7. Settings and billing
   - Workspace settings.
   - Team members.
   - API keys.
   - Stripe portal.

## API Endpoints

Initial REST endpoints:

- `POST /api/auth/signup`
- `POST /api/auth/login`
- `GET /api/accounts/providers`
- `GET /api/oauth/:platform/start`
- `GET /api/oauth/:platform/callback`
- `GET /api/accounts`
- `DELETE /api/accounts/:id`
- `POST /api/media/upload-url`
- `POST /api/posts`
- `GET /api/posts`
- `GET /api/posts/:id`
- `PATCH /api/posts/:id`
- `POST /api/posts/:id/publish`
- `POST /api/posts/:id/schedule`
- `POST /api/post-targets/:id/retry`
- `GET /api/schedules`
- `GET /api/analytics/summary`
- `GET /api/analytics/posts/:postId`
- `POST /api/api-keys`
- `DELETE /api/api-keys/:id`
- `GET /api/billing/plans`
- `POST /api/billing/checkout`
- `POST /api/webhooks/stripe`
- `POST /api/webhooks/:platform`

## Agent and MCP Plan

Agent tools should map to backend operations:

- `list_accounts`: show connected destinations.
- `upload_media`: upload or register media assets.
- `create_post`: create a draft with caption and media.
- `validate_post`: return platform-specific warnings.
- `schedule_post`: schedule a draft for one or more accounts.
- `publish_post`: publish immediately.
- `get_post_status`: show per-platform results.
- `get_analytics`: return normalized performance metrics.

MCP can come after the REST API is stable. The MCP server should call the same service layer as the app and REST API.

## Security Requirements

- Never request or store user social passwords.
- Use official OAuth or platform-approved auth flows only.
- Validate OAuth `state` and redirect URI.
- Encrypt provider tokens at rest.
- Support token revocation and reconnect flows.
- Use scoped API keys for agent access.
- Keep audit logs for account connections, token refresh, publish actions, API key use, and billing changes.
- Verify provider webhook signatures.
- Add rate limits for API keys and publish endpoints.
- Provide account deletion and data export paths.

## MVP Milestones

1. Finish dependency installation and build validation for the current scaffold.
2. Build dashboard and composer UI on top of the existing landing page.
3. Add PostgreSQL schema and migrations.
4. Add auth and workspace membership.
5. Implement media upload metadata and object storage integration.
6. Implement one real provider from OAuth to publish status.
7. Add queue-based scheduling and retries.
8. Add analytics refresh for the first provider.
9. Add Stripe plan limits.
10. Expand remaining providers one by one.