# Backend Roadmap

This project is scaffolded for real OAuth and real publishing. The first production milestone should prove one provider end to end before adding the other nine.

## Core Architecture

- API server: Express TypeScript service under `api/`.
- Shared types: common post, account, platform, media, and analytics models under `packages/shared/`.
- Connector layer: each platform implements `SocialConnector` with OAuth, token refresh, validation, publishing, and analytics.
- Storage: PostgreSQL for durable data, Redis/BullMQ or equivalent for background jobs, and object storage for media.
- Security: official OAuth only, encrypted token storage, OAuth state validation, scoped API keys, audit logs, and provider webhook signature verification.

## Suggested Delivery Phases

1. Add database schema and migrations for users, workspaces, social accounts, media assets, posts, post targets, publish attempts, and analytics snapshots.
2. Add auth and workspace membership before any provider connection flow.
3. Implement encrypted token storage with key rotation notes before saving OAuth tokens.
4. Build one provider fully, including OAuth start/callback, token refresh, post validation, media upload, publish, retry, status, and analytics refresh.
5. Add the durable publish queue and scheduled job worker.
6. Add remaining providers one at a time behind the same connector contract.
7. Add Stripe billing and plan enforcement.
8. Add API keys and MCP-style agent endpoints once core publishing is reliable.

## Platform Approval Notes

- Meta platforms require careful permission review for Facebook Pages, Instagram publishing, and Threads.
- TikTok and YouTube require app verification for publishing and analytics scopes.
- LinkedIn posting permissions depend on member/company page use cases.
- Google Business APIs require verified business/profile access.
- Pinterest and X/Twitter have plan, rate-limit, and media upload constraints that should be reflected in composer validation.

## First Provider Recommendation

Start with Bluesky or X/Twitter for the first complete connector because they are generally simpler than Meta/TikTok/YouTube app review paths. After one provider is proven, repeat the same flow for the higher-friction platforms.